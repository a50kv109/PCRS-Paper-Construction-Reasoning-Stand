/**
 * AGENT READINESS SMOKE TEST SUITE (T01 - T10)
 * 
 * Strict architectural verification:
 * - Deterministic machine-readable interface between Agent and Geometry Stand.
 * - Agent is UNTRUSTED: The stand independently calculates expected values and enforces truth.
 * - Centralized tolerance architecture (Package 06) is strictly honored.
 * - Domain-level vocabulary without internal IDs.
 */

import {
  createPoint3D,
  createSphere3D,
  createCanonicalGeometryState,
  handleAgentRequest,
  extractAgentStateSnapshot,
  getResolvedTolerances,
  runUntrustedAgentSimulation,
  AgentRequest,
  AgentResponse,
} from '../core';

interface TestResult {
  id: string;
  purpose: string;
  status: 'PASS' | 'FAIL';
  evidence: string;
}

const results: TestResult[] = [];

function runTest(id: string, purpose: string, fn: () => { pass: boolean; evidence: string }) {
  try {
    const { pass, evidence } = fn();
    results.push({
      id,
      purpose,
      status: pass ? 'PASS' : 'FAIL',
      evidence,
    });
  } catch (err: any) {
    results.push({
      id,
      purpose,
      status: 'FAIL',
      evidence: `Unexpected error thrown during test: ${err.message}`,
    });
  }
}

// Helper: Standard Regular Tetrahedron on unit sphere R = 1
function getCanonicalTetrahedronState(R: number = 1.0) {
  const sphere = createSphere3D(createPoint3D(0, 0, 0), R);
  const vertices = {
    A: createPoint3D(0, 0, R),
    B: createPoint3D((2 * Math.sqrt(2) / 3) * R, 0, (-1 / 3) * R),
    C: createPoint3D((-Math.sqrt(2) / 3) * R, (-Math.sqrt(6) / 3) * R, (-1 / 3) * R),
    D: createPoint3D((-Math.sqrt(2) / 3) * R, (Math.sqrt(6) / 3) * R, (-1 / 3) * R),
  };
  return createCanonicalGeometryState(sphere, vertices);
}

// ============================================================
// TEST DEFINITIONS (T01 - T10)
// ============================================================

// T01: Agent can obtain current geometry state
runTest('T01', 'Agent can obtain current geometry state via machine-readable GET_STATE', () => {
  const state = getCanonicalTetrahedronState(1.0);
  const req: AgentRequest = { operation: 'GET_STATE' };
  const res = handleAgentRequest(req, state);

  const pass =
    res.status === 'VALID' &&
    res.state !== undefined &&
    res.state.sphere.radius === 1.0 &&
    res.state.isValid === true &&
    res.state.orientation === 'POSITIVE' &&
    res.state.isRegular === true &&
    res.state.vertices.A.z === 1.0 &&
    typeof res.state.measurements.volume === 'number' &&
    res.state.measurements.volume > 0.5;

  return {
    pass,
    evidence: `GET_STATE returned status="${res.status}". Sphere R=${res.state?.sphere.radius}, volume=${res.state?.measurements.volume.toFixed(5)}, orientation=${res.state?.orientation}, isRegular=${res.state?.isRegular}.`,
  };
});

// T02: Agent can request a deterministic measurement
runTest('T02', 'Agent can request a deterministic measurement via SOLVE', () => {
  const state = getCanonicalTetrahedronState(1.0);
  const reqVolume: AgentRequest = { operation: 'SOLVE', target: 'volume' };
  const resVolume = handleAgentRequest(reqVolume, state);

  const reqEdge: AgentRequest = { operation: 'SOLVE', target: 'edge_AB' };
  const resEdge = handleAgentRequest(reqEdge, state);

  const pass =
    resVolume.status === 'VALID' &&
    typeof resVolume.result === 'number' &&
    Math.abs(Number(resVolume.result) - 0.5132) < 0.001 &&
    resEdge.status === 'VALID' &&
    typeof resEdge.result === 'number' &&
    Math.abs(Number(resEdge.result) - (2 * Math.sqrt(6) / 3)) < 0.001;

  return {
    pass,
    evidence: `SOLVE target "volume" -> ${resVolume.result} (expected ~0.51320). SOLVE target "edge_AB" -> ${resEdge.result} (expected ~1.63299). Both valid.`,
  };
});

// T03: Correct agent result -> VALID
runTest('T03', 'Correct agent assertion produces VALID with machine-readable evidence', () => {
  const state = getCanonicalTetrahedronState(1.0);
  const correctVolume = 0.5132002392796676; // (8*sqrt(3)/27) * R^3

  const req: AgentRequest = {
    operation: 'VERIFY_RESULT',
    claim: {
      target: 'volume',
      value: correctVolume,
    },
  };
  const res = handleAgentRequest(req, state);

  const pass =
    res.status === 'VALID' &&
    res.target === 'volume' &&
    res.claimed === correctVolume &&
    res.difference !== undefined &&
    res.difference < 1e-10;

  return {
    pass,
    evidence: `VERIFY_RESULT returned status="${res.status}", diff=${res.difference?.toExponential(2)}, toleranceUsed=${res.toleranceUsed?.toExponential(2)}. Evidence: "${res.evidence}".`,
  };
});

// T04: Incorrect agent result -> INVALID (Negative Verification)
runTest('T04', 'Incorrect agent assertion produces INVALID with discrepancy evidence', () => {
  const state = getCanonicalTetrahedronState(1.0);
  const incorrectVolume = 0.500000; // Deliberately wrong claim

  const req: AgentRequest = {
    operation: 'VERIFY_RESULT',
    claim: {
      target: 'volume',
      value: incorrectVolume,
    },
  };
  const res = handleAgentRequest(req, state);

  const pass =
    res.status === 'INVALID' &&
    res.target === 'volume' &&
    res.claimed === incorrectVolume &&
    res.expected !== undefined &&
    res.difference !== undefined &&
    res.difference > 0.01;

  return {
    pass,
    evidence: `Negative test succeeded: claimed=${res.claimed}, expected=${Number(res.expected).toFixed(6)}, diff=${res.difference?.toFixed(6)} > tolerance ${res.toleranceUsed?.toExponential(2)}. Status="${res.status}".`,
  };
});

// T05: Unsupported target -> UNKNOWN
runTest('T05', 'Unsupported geometric target returns UNKNOWN without hallucinating', () => {
  const state = getCanonicalTetrahedronState(1.0);
  const reqSolve: AgentRequest = {
    operation: 'SOLVE',
    target: 'hyperspace_entropy_flux',
  };
  const resSolve = handleAgentRequest(reqSolve, state);

  const reqVerify: AgentRequest = {
    operation: 'VERIFY_RESULT',
    claim: {
      target: 'quantum_spin_number',
      value: 42,
    },
  };
  const resVerify = handleAgentRequest(reqVerify, state);

  const pass =
    resSolve.status === 'UNKNOWN' &&
    resVerify.status === 'UNKNOWN';

  return {
    pass,
    evidence: `SOLVE unknown target returned status="${resSolve.status}". VERIFY_RESULT unknown target returned status="${resVerify.status}". Neither invented an answer.`,
  };
});

// T06: Invalid geometry -> explicit failure status (PRECONDITION_FAILED)
runTest('T06', 'Invalid geometry input produces explicit PRECONDITION_FAILED', () => {
  // Deliberately construct an invalid state (radius = -1)
  const invalidSphere = createSphere3D(createPoint3D(0, 0, 0), -1.0);
  const vertices = {
    A: createPoint3D(0, 0, 1),
    B: createPoint3D(1, 0, 0),
    C: createPoint3D(0, 1, 0),
    D: createPoint3D(0, 0, -1),
  };
  const invalidState = createCanonicalGeometryState(invalidSphere, vertices);

  const resGetState = handleAgentRequest({ operation: 'GET_STATE' }, invalidState);
  const resSolve = handleAgentRequest({ operation: 'SOLVE', target: 'volume' }, invalidState);
  const resVerify = handleAgentRequest({ operation: 'VERIFY_RESULT', claim: { target: 'volume', value: 0.5 } }, invalidState);

  const pass =
    resGetState.status === 'PRECONDITION_FAILED' &&
    resSolve.status === 'PRECONDITION_FAILED' &&
    resVerify.status === 'PRECONDITION_FAILED';

  return {
    pass,
    evidence: `Invalid geometry (R=-1) produced PRECONDITION_FAILED across all operations (GET_STATE, SOLVE, VERIFY_RESULT). Stand refused to perform calculations on invalid state.`,
  };
});

// T07: Agent cannot override deterministic result
runTest('T07', 'Agent cannot override deterministic result; stand computes independently', () => {
  const state = getCanonicalTetrahedronState(1.0);
  // An untrusted agent claims volume is 10.0 and asserts tolerance should be huge
  const maliciousReq: AgentRequest = {
    operation: 'VERIFY_RESULT',
    claim: {
      target: 'volume',
      value: 10.0,
    },
  };
  const res = handleAgentRequest(maliciousReq, state);

  const pass =
    res.status === 'INVALID' &&
    Math.abs(Number(res.expected) - 0.513200) < 0.001 &&
    res.claimed === 10.0;

  return {
    pass,
    evidence: `Agent claimed 10.0, but Stand independently derived expected=${Number(res.expected).toFixed(6)} and firmly rejected claim with status="${res.status}".`,
  };
});

// T08: Tolerance comes from the centralized tolerance architecture
runTest('T08', 'Centralized scale-aware tolerance policy (Package 06) is enforced', () => {
  const R1 = 1.0;
  const tol1 = getResolvedTolerances(R1);
  const state1 = getCanonicalTetrahedronState(R1);

  const res1 = handleAgentRequest({ operation: 'SOLVE', target: 'volume' }, state1);

  const R10 = 10.0;
  const tol10 = getResolvedTolerances(R10);
  const state10 = getCanonicalTetrahedronState(R10);
  const res10 = handleAgentRequest({ operation: 'SOLVE', target: 'volume' }, state10);

  const pass =
    res1.toleranceUsed === tol1.epsVolume &&
    res10.toleranceUsed === tol10.epsVolume &&
    Math.abs(tol10.epsVolume - tol1.epsVolume * 1000) < 1e-12; // scales with R^3

  return {
    pass,
    evidence: `Volume tolerance at R=1 is ${res1.toleranceUsed?.toExponential(2)} (epsVolume). At R=10 it is ${res10.toleranceUsed?.toExponential(2)} (scales exactly with R^3 = 1000x).`,
  };
});

// T09: No internal derivation ID is required by the public agent contract
runTest('T09', 'Public agent contract operates purely on domain vocabulary', () => {
  const state = getCanonicalTetrahedronState(1.0);
  const domainTargets = [
    'volume',
    'surface_area',
    'edge_AB',
    'edge_CD',
    'face_ABC',
    'orientation',
    'is_regular',
    'centroid',
    'sphere_radius',
  ];

  let allSupported = true;
  for (const target of domainTargets) {
    const res = handleAgentRequest({ operation: 'SOLVE', target }, state);
    if (res.status !== 'VALID') {
      allSupported = false;
      break;
    }
  }

  return {
    pass: allSupported,
    evidence: `All ${domainTargets.length} domain targets resolved to VALID without requiring internal IDs or DAG hashes: [${domainTargets.join(', ')}].`,
  };
});

// T10: Simulated untrusted agent full scenario + correction loop
runTest('T10', 'Full untrusted agent simulation and correction loop execute deterministically', () => {
  const state = getCanonicalTetrahedronState(1.0);

  // 1. Run simulation protocol
  const simReport = runUntrustedAgentSimulation(state);
  if (!simReport.allPassed || !simReport.correctionLoopPassed) {
    return {
      pass: false,
      evidence: `Agent simulation protocol failed: ${simReport.summary}`,
    };
  }

  // 2. Explicit Correction Loop Validation:
  // Step A: Agent proposes wrong volume 0.48
  const wrongClaimRes = handleAgentRequest(
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'volume', value: 0.48 },
    },
    state
  );

  if (wrongClaimRes.status !== 'INVALID' || wrongClaimRes.expected === undefined) {
    return { pass: false, evidence: 'Correction loop Step A (rejection of wrong claim) failed' };
  }

  // Step B: Stand provides deterministic feedback without yielding to agent
  const trueExpected = Number(wrongClaimRes.expected);

  // Step C: Agent updates claim to true value and Stand confirms
  const correctedClaimRes = handleAgentRequest(
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'volume', value: trueExpected },
    },
    state
  );

  if (correctedClaimRes.status !== 'VALID') {
    return { pass: false, evidence: 'Correction loop Step C (validation of corrected claim) failed' };
  }

  // 3. Secondary Claims (edge_AB, surface_area, orientation):
  const edgeSolve = handleAgentRequest({ operation: 'SOLVE', target: 'edge_AB' }, state);
  const edgeVal = edgeSolve.result;
  const edgeValid = handleAgentRequest({ operation: 'VERIFY_RESULT', claim: { target: 'edge_AB', value: edgeVal } }, state);
  const edgeInvalid = handleAgentRequest({ operation: 'VERIFY_RESULT', claim: { target: 'edge_AB', value: 99.0 } }, state);

  const orientValid = handleAgentRequest({ operation: 'VERIFY_RESULT', claim: { target: 'orientation', value: 'POSITIVE' } }, state);
  const orientInvalid = handleAgentRequest({ operation: 'VERIFY_RESULT', claim: { target: 'orientation', value: 'NEGATIVE' } }, state);

  const pass =
    simReport.allPassed &&
    wrongClaimRes.status === 'INVALID' &&
    correctedClaimRes.status === 'VALID' &&
    edgeValid.status === 'VALID' &&
    edgeInvalid.status === 'INVALID' &&
    orientValid.status === 'VALID' &&
    orientInvalid.status === 'INVALID';

  return {
    pass,
    evidence: `Simulation (${simReport.passedSteps}/${simReport.totalSteps} steps) & Correction Loop passed: [Propose 0.48 -> INVALID] -> [Parse feedback -> ${trueExpected.toFixed(5)}] -> [Resubmit -> VALID]. Non-volume claims (edge_AB, orientation) verified.`,
  };
});

// ============================================================
// EXECUTION & REPORTING
// ============================================================

console.log('============================================================');
console.log('AGENT READINESS SMOKE TEST — EXECUTION REPORT');
console.log('============================================================\n');

let passCount = 0;
let failCount = 0;

for (const r of results) {
  const badge = r.status === 'PASS' ? '[PASS]' : '[FAIL]';
  console.log(`${badge} ${r.id}: ${r.purpose}`);
  console.log(`       Evidence: ${r.evidence}\n`);
  if (r.status === 'PASS') passCount++;
  else failCount++;
}

console.log('============================================================');
console.log(`TOTAL TESTS EXECUTED: ${results.length}`);
console.log(`PASSED: ${passCount}`);
console.log(`FAILED: ${failCount}`);
console.log('============================================================');

if (failCount > 0) {
  console.error('\nAGENT READINESS SMOKE TEST: FAILED / BLOCKED');
  process.exit(1);
} else {
  console.log('\nAGENT READINESS SMOKE TEST: PASS');
  console.log('LIVE EXTERNAL AGENT EXECUTION: NOT PERFORMED');
  process.exit(0);
}
