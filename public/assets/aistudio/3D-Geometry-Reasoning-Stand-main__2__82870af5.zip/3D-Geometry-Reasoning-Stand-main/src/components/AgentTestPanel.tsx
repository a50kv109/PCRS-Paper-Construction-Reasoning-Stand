/**
 * AGENT TEST & PLAYGROUND PANEL
 * 
 * Interactive visual console & Raw JSON Playground for the machine-readable Agent Interface.
 * Allows testing of GET_STATE, SOLVE, and VERIFY_RESULT, as well as executing the full
 * untrusted agent simulation and correction loop.
 */

import React, { useState, useMemo } from 'react';
import {
  CanonicalGeometryState,
  handleAgentRequest,
  agentRequest,
  runUntrustedAgentSimulation,
  SimulationReport,
  AgentRequest,
  AgentResponse,
  AgentGeometricTarget,
} from '../core';
import { 
  Bot, 
  ChevronDown, 
  ChevronRight, 
  Play, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  AlertTriangle,
  Code2,
  Terminal,
  RotateCcw,
  Sparkles
} from 'lucide-react';

interface AgentTestPanelProps {
  canonicalState: CanonicalGeometryState;
}

export const AgentTestPanel: React.FC<AgentTestPanelProps> = ({ canonicalState }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<'form' | 'json' | 'sim'>('form');

  // Form Mode State
  const [operation, setOperation] = useState<'GET_STATE' | 'SOLVE' | 'VERIFY_RESULT'>('VERIFY_RESULT');
  const [target, setTarget] = useState<AgentGeometricTarget>('volume');
  const [claimedValue, setClaimedValue] = useState<string>('0.513200');
  const [lastResponse, setLastResponse] = useState<AgentResponse | null>(null);

  // Raw JSON Playground State
  const [rawJsonInput, setRawJsonInput] = useState<string>(
    JSON.stringify(
      {
        operation: 'VERIFY_RESULT',
        claim: {
          target: 'volume',
          value: 0.513200,
        },
      },
      null,
      2
    )
  );
  const [rawJsonResponse, setRawJsonResponse] = useState<AgentResponse | null>(null);

  // Automated Simulation State
  const [simReport, setSimReport] = useState<SimulationReport | null>(null);

  // Active Form Request Preview
  const currentFormRequest: AgentRequest = useMemo(() => {
    if (operation === 'GET_STATE') {
      return { operation: 'GET_STATE' };
    }
    if (operation === 'SOLVE') {
      return { operation: 'SOLVE', target };
    }
    return {
      operation: 'VERIFY_RESULT',
      claim: {
        target,
        value: target === 'is_regular' ? claimedValue === 'true' : isNaN(Number(claimedValue)) ? claimedValue : Number(claimedValue),
      },
    };
  }, [operation, target, claimedValue]);

  const handleExecuteForm = () => {
    const res = handleAgentRequest(currentFormRequest, canonicalState);
    setLastResponse(res);
  };

  const handleExecuteRawJson = () => {
    const res = agentRequest(rawJsonInput, canonicalState);
    setRawJsonResponse(res);
  };

  const handleRunSimulation = () => {
    const report = runUntrustedAgentSimulation(canonicalState);
    setSimReport(report);
  };

  return (
    <div id="agent-test-panel" className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
      {/* Accordion Header */}
      <button
        type="button"
        id="toggle-agent-panel-btn"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-3.5 py-2.5 bg-slate-900 hover:bg-slate-850 flex items-center justify-between transition-colors border-b border-slate-800/60"
      >
        <div className="flex items-center gap-1.5">
          <Bot className="w-3.5 h-3.5 text-sky-400" />
          <span className="text-[11px] font-bold text-slate-200 uppercase tracking-wide">
            8. Проверка агента (Agent Readiness & Playground)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 text-[10px] font-mono text-sky-400 bg-sky-950/60 px-1.5 py-0.5 rounded border border-sky-800/60">
            Machine-Readable
          </span>
          {isOpen ? (
            <ChevronDown className="w-4 h-4 text-slate-400" />
          ) : (
            <ChevronRight className="w-4 h-4 text-slate-400" />
          )}
        </div>
      </button>

      {/* Accordion Body */}
      {isOpen && (
        <div className="p-3 space-y-3 text-xs bg-slate-950/50">
          <p className="text-[11px] text-slate-400">
            Интерфейс для внешних AI-агентов. Агент не обладает доверием: стенд независимо вычисляет эталон и выносит строгий вердикт (VALID / INVALID / UNKNOWN).
          </p>

          {/* Mode Switcher */}
          <div className="flex rounded-lg bg-slate-900 p-0.5 border border-slate-800">
            <button
              type="button"
              onClick={() => setMode('form')}
              className={`flex-1 py-1 rounded text-[10px] font-bold transition-colors ${
                mode === 'form'
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Конструктор запроса
            </button>
            <button
              type="button"
              onClick={() => setMode('json')}
              className={`flex-1 py-1 rounded text-[10px] font-bold transition-colors flex items-center justify-center gap-1 ${
                mode === 'json'
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3 h-3" />
              JSON Playground
            </button>
            <button
              type="button"
              onClick={() => setMode('sim')}
              className={`flex-1 py-1 rounded text-[10px] font-bold transition-colors flex items-center justify-center gap-1 ${
                mode === 'sim'
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3 h-3 text-amber-400" />
              Симуляция агента
            </button>
          </div>

          {/* MODE 1: FORM BUILDER */}
          {mode === 'form' && (
            <div className="space-y-3">
              {/* Operation Selector */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase">Операция агента</label>
                <div className="grid grid-cols-3 gap-1">
                  {(['GET_STATE', 'SOLVE', 'VERIFY_RESULT'] as const).map((op) => (
                    <button
                      key={op}
                      type="button"
                      onClick={() => {
                        setOperation(op);
                        setLastResponse(null);
                      }}
                      className={`px-2 py-1 rounded text-[10px] font-mono font-bold transition-colors border ${
                        operation === op
                          ? 'bg-sky-500/20 border-sky-500/50 text-sky-300'
                          : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {op}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target & Claim Inputs (when applicable) */}
              {operation !== 'GET_STATE' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Целевая величина</label>
                    <select
                      value={target}
                      onChange={(e) => setTarget(e.target.value as AgentGeometricTarget)}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:outline-none focus:border-sky-500"
                    >
                      <option value="volume">volume (объём)</option>
                      <option value="surface_area">surface_area (площадь)</option>
                      <option value="edge_AB">edge_AB (ребро AB)</option>
                      <option value="face_ABC">face_ABC (грань ABC)</option>
                      <option value="orientation">orientation (ориентация)</option>
                      <option value="is_regular">is_regular (правильность)</option>
                      <option value="centroid">centroid (центроид)</option>
                    </select>
                  </div>

                  {operation === 'VERIFY_RESULT' && (
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Утверждение агента</label>
                      <input
                        type="text"
                        value={claimedValue}
                        onChange={(e) => setClaimedValue(e.target.value)}
                        placeholder="Например: 0.513200"
                        className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200 font-mono focus:outline-none focus:border-sky-500"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Quick Presets for VERIFY_RESULT */}
              {operation === 'VERIFY_RESULT' && (
                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  <span className="text-[9px] text-slate-500 self-center uppercase font-bold">Пресеты теста:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setTarget('volume');
                      setClaimedValue('0.513200');
                    }}
                    className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-950/40 border border-emerald-800/40 text-emerald-400 hover:bg-emerald-900/50"
                  >
                    Верный объём (~0.5132)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTarget('volume');
                      setClaimedValue('0.500000');
                    }}
                    className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-rose-950/40 border border-rose-800/40 text-rose-400 hover:bg-rose-900/50"
                  >
                    Неверный объём (0.500)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTarget('orientation');
                      setClaimedValue('NEGATIVE');
                    }}
                    className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-rose-950/40 border border-rose-800/40 text-rose-400 hover:bg-rose-900/50"
                  >
                    Ошибочная ориентация
                  </button>
                </div>
              )}

              {/* Execute Button */}
              <button
                type="button"
                onClick={handleExecuteForm}
                className="w-full py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Выполнить запрос к стенду</span>
              </button>

              {/* Response Box */}
              {lastResponse && renderResponseBadge(lastResponse)}
            </div>
          )}

          {/* MODE 2: RAW JSON PLAYGROUND */}
          {mode === 'json' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-bold text-slate-400 uppercase">Входной JSON-запрос</label>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setRawJsonInput(JSON.stringify({ operation: 'GET_STATE' }, null, 2))}
                    className="text-[9px] font-mono px-1 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    GET_STATE
                  </button>
                  <button
                    type="button"
                    onClick={() => setRawJsonInput(JSON.stringify({ operation: 'SOLVE', target: 'volume' }, null, 2))}
                    className="text-[9px] font-mono px-1 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    SOLVE volume
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setRawJsonInput(
                        JSON.stringify(
                          { operation: 'VERIFY_RESULT', claim: { target: 'volume', value: 0.513200239 } },
                          null,
                          2
                        )
                      )
                    }
                    className="text-[9px] font-mono px-1 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    VERIFY valid
                  </button>
                </div>
              </div>

              <textarea
                value={rawJsonInput}
                onChange={(e) => setRawJsonInput(e.target.value)}
                rows={6}
                className="w-full bg-slate-900 border border-slate-750 rounded-lg p-2 text-[11px] font-mono text-sky-200 focus:outline-none focus:border-sky-500"
              />

              <button
                type="button"
                onClick={handleExecuteRawJson}
                className="w-full py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Отправить JSON в Stand (agentRequest)</span>
              </button>

              {rawJsonResponse && renderResponseBadge(rawJsonResponse)}
            </div>
          )}

          {/* MODE 3: AUTOMATED UNTRUSTED AGENT SIMULATION */}
          {mode === 'sim' && (
            <div className="space-y-3">
              <p className="text-[11px] text-slate-300">
                Запуск полного протокола симуляции ненадежного внешнего агента (GET_STATE → SOLVE → верный claim → намеренная ошибка → UNKNOWN → PRECONDITION_FAILED → отказ в оверрайде → корректирующий цикл).
              </p>

              <button
                type="button"
                onClick={handleRunSimulation}
                className="w-full py-1.5 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white rounded font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Запустить локальную симуляцию сценария агента</span>
              </button>

              {simReport && (
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-[10px] font-bold uppercase text-slate-300">Результат симуляции:</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        simReport.allPassed
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                          : 'bg-rose-950 text-rose-300 border border-rose-700'
                      }`}
                    >
                      {simReport.allPassed ? 'ALL STEPS PASSED (100%)' : 'SIMULATION FAILED'}
                    </span>
                  </div>

                  <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                    {simReport.logs.map((log) => (
                      <div
                        key={log.step}
                        className="p-1.5 rounded bg-slate-900 border border-slate-800/80 text-[10px] font-mono flex items-start justify-between gap-2"
                      >
                        <div>
                          <div className="font-bold text-slate-200">
                            {log.step}. {log.name}
                          </div>
                          <div className="text-slate-400 text-[9px]">{log.notes}</div>
                        </div>
                        <span
                          className={`shrink-0 px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            log.pass
                              ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/80'
                              : 'bg-rose-950/80 text-rose-400 border border-rose-800/80'
                          }`}
                        >
                          {log.response.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

function renderResponseBadge(res: AgentResponse) {
  return (
    <div className="mt-2 space-y-1.5 p-2 rounded-lg bg-slate-900 border border-slate-800">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Code2 className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-[10px] font-mono font-bold text-slate-300">
            Вердикт стенда:
          </span>
        </div>

        {/* Status Badge */}
        <span
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold font-mono border ${
            res.status === 'VALID'
              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80'
              : res.status === 'INVALID'
              ? 'bg-rose-950/80 text-rose-300 border-rose-700/80'
              : res.status === 'PRECONDITION_FAILED'
              ? 'bg-amber-950/80 text-amber-300 border-amber-700/80'
              : 'bg-slate-800 text-slate-300 border-slate-700'
          }`}
        >
          {res.status === 'VALID' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
          {res.status === 'INVALID' && <XCircle className="w-3 h-3 text-rose-400" />}
          {res.status === 'PRECONDITION_FAILED' && <AlertTriangle className="w-3 h-3 text-amber-400" />}
          {res.status === 'UNKNOWN' && <HelpCircle className="w-3 h-3 text-slate-400" />}
          {res.status}
        </span>
      </div>

      {/* Evidence String */}
      <div className="text-[10px] text-slate-300 font-mono bg-slate-950 p-1.5 rounded border border-slate-800/80 leading-relaxed">
        {res.evidence}
      </div>

      {/* Raw JSON snapshot */}
      <details className="text-[9px] text-slate-400">
        <summary className="cursor-pointer hover:text-slate-200">Полный ответ JSON</summary>
        <pre className="mt-1 p-2 bg-slate-950 rounded border border-slate-800 overflow-x-auto text-[9px] text-slate-300 font-mono">
          {JSON.stringify(res, null, 2)}
        </pre>
      </details>
    </div>
  );
}
