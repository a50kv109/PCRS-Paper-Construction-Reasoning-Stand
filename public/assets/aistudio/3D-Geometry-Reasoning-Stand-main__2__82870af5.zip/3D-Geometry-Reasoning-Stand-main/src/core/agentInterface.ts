/**
 * AGENT READINESS INTERFACE — DETERMINISTIC MACHINE-READABLE API
 * 
 * Strict Architectural Principles:
 * 1. UNTRUSTED AGENT: The agent may propose states, request calculations, or submit claims.
 *    The Geometry Stand is the sole deterministic verifier. The stand never trusts agent values.
 * 2. NO SECOND GEOMETRY MODEL: All evaluations reuse the Canonical Geometry State and
 *    the centralized tolerance system (Package 06).
 * 3. DOMAIN VOCABULARY ONLY: Uses natural geometric domain terms ("volume", "surface_area",
 *    "edge_AB", "face_ABC", "orientation", "is_regular", "centroid", "sphere_radius").
 *    Zero requirement for internal implementation IDs, DAG node hashes, or rendering IDs.
 */

import {
  Point3D,
  Sphere3D,
  VertexId,
  EdgeId,
  FaceId,
  CanonicalGeometryState,
} from './types';
import {
  createPoint3D,
  createSphere3D,
  createCanonicalGeometryState,
  validateGeometryState,
  distance3D,
} from './geometryState';
import { computeDerivedMetrics, ComprehensiveGeometryMetrics } from './metrics';
import { getResolvedTolerances } from './tolerances';

// ============================================================
// 1. DOMAIN TARGETS & OPERATION TYPES
// ============================================================

export type AgentGeometricTarget =
  | 'volume'
  | 'signed_volume'
  | 'absolute_volume'
  | 'surface_area'
  | 'total_surface_area'
  | 'is_regular'
  | 'orientation'
  | 'sphere_radius'
  | 'sphere_center'
  | 'centroid'
  | 'edge_AB'
  | 'edge_AC'
  | 'edge_AD'
  | 'edge_BC'
  | 'edge_BD'
  | 'edge_CD'
  | 'face_ABC'
  | 'face_ABD'
  | 'face_ACD'
  | 'face_BCD'
  | 'vertex_A'
  | 'vertex_B'
  | 'vertex_C'
  | 'vertex_D'
  | (string & {});

export type AgentOperationType = 'GET_STATE' | 'SOLVE' | 'VERIFY_RESULT';

export type AgentEvaluationStatus =
  | 'VALID'
  | 'INVALID'
  | 'UNKNOWN'
  | 'PRECONDITION_FAILED'
  | 'MISSING_INPUT';

// ============================================================
// 2. REQUEST & RESPONSE SCHEMAS
// ============================================================

export interface AgentGetStateRequest {
  readonly operation: 'GET_STATE';
}

export interface AgentSolveRequest {
  readonly operation: 'SOLVE';
  readonly target: AgentGeometricTarget;
}

export interface AgentClaim {
  readonly target: AgentGeometricTarget;
  readonly value: number | string | boolean | Point3D | any;
}

export interface AgentGivenContext {
  readonly sphere?: Sphere3D;
  readonly vertices?: Record<VertexId, Point3D>;
  readonly radius?: number;
}

export interface AgentVerifyRequest {
  readonly operation: 'VERIFY_RESULT';
  readonly given?: AgentGivenContext;
  readonly claim: AgentClaim;
}

export type AgentRequest = AgentGetStateRequest | AgentSolveRequest | AgentVerifyRequest;

export interface AgentGeometryStateSnapshot {
  readonly sphere: {
    readonly center: Point3D;
    readonly radius: number;
  };
  readonly vertices: Readonly<Record<VertexId, Point3D>>;
  readonly isValid: boolean;
  readonly validationCode: string;
  readonly orientation: 'POSITIVE' | 'NEGATIVE' | 'COPLANAR';
  readonly isRegular: boolean;
  readonly measurements: {
    readonly volume: number;
    readonly surface_area: number;
    readonly edge_lengths: Readonly<Record<EdgeId, number>>;
    readonly face_areas: Readonly<Record<FaceId, number>>;
    readonly centroid: Point3D;
  };
}

export interface AgentResponse {
  readonly operation: AgentOperationType;
  readonly status: AgentEvaluationStatus;
  readonly target?: AgentGeometricTarget;
  readonly state?: AgentGeometryStateSnapshot;
  readonly result?: number | string | boolean | Point3D;
  readonly expected?: number | string | boolean | Point3D;
  readonly claimed?: number | string | boolean | Point3D;
  readonly difference?: number;
  readonly toleranceUsed?: number;
  readonly evidence: string;
}

// ============================================================
// 3. CORE AGENT INTERFACE HANDLERS
// ============================================================

/**
 * Extracts a domain-level clean snapshot of the canonical geometry state.
 */
export function extractAgentStateSnapshot(state: CanonicalGeometryState): AgentGeometryStateSnapshot {
  const validation = validateGeometryState(state.sphere, state.vertices);
  const metrics = computeDerivedMetrics(state);

  const edgeLengths: Record<EdgeId, number> = {} as any;
  for (const [key, metric] of Object.entries(metrics.edges)) {
    edgeLengths[key as EdgeId] = metric.length;
  }

  const faceAreas: Record<FaceId, number> = {} as any;
  for (const [key, metric] of Object.entries(metrics.faces)) {
    faceAreas[key as FaceId] = metric.area;
  }

  return {
    sphere: {
      center: state.sphere.center,
      radius: state.sphere.radius,
    },
    vertices: state.vertices,
    isValid: validation.isValid,
    validationCode: validation.validationCode,
    orientation: metrics.global.orientation,
    isRegular: metrics.global.isRegular,
    measurements: {
      volume: metrics.global.absoluteVolume,
      surface_area: metrics.global.totalSurfaceArea,
      edge_lengths: Object.freeze(edgeLengths),
      face_areas: Object.freeze(faceAreas),
      centroid: metrics.global.centroid,
    },
  };
}

/**
 * Deterministically resolves a geometric target from canonical metrics.
 */
function resolveGeometricTarget(
  target: AgentGeometricTarget,
  metrics: ComprehensiveGeometryMetrics,
  state: CanonicalGeometryState
): { value: number | string | boolean | Point3D; tolerance: number } | null {
  const R = state.sphere.radius;
  const tol = getResolvedTolerances(R);
  const normalized = target.toLowerCase().trim();

  switch (normalized) {
    case 'volume':
    case 'absolute_volume':
      return { value: metrics.global.absoluteVolume, tolerance: tol.epsVolume };
    case 'signed_volume':
      return { value: metrics.global.signedVolume, tolerance: tol.epsVolume };
    case 'surface_area':
    case 'total_surface_area':
      return { value: metrics.global.totalSurfaceArea, tolerance: tol.epsFaceArea };
    case 'is_regular':
    case 'regularity':
      return { value: metrics.global.isRegular, tolerance: 0 };
    case 'orientation':
      return { value: metrics.global.orientation, tolerance: 0 };
    case 'sphere_radius':
    case 'radius':
      return { value: state.sphere.radius, tolerance: tol.epsSphere };
    case 'sphere_center':
      return { value: state.sphere.center, tolerance: tol.epsSphere };
    case 'centroid':
      return { value: metrics.global.centroid, tolerance: tol.epsSphere };
    
    // Edges (e.g., edge_AB or AB)
    case 'edge_ab':
    case 'ab':
      return { value: metrics.edges.AB.length, tolerance: tol.epsSphere };
    case 'edge_ac':
    case 'ac':
      return { value: metrics.edges.AC.length, tolerance: tol.epsSphere };
    case 'edge_ad':
    case 'ad':
      return { value: metrics.edges.AD.length, tolerance: tol.epsSphere };
    case 'edge_bc':
    case 'bc':
      return { value: metrics.edges.BC.length, tolerance: tol.epsSphere };
    case 'edge_bd':
    case 'bd':
      return { value: metrics.edges.BD.length, tolerance: tol.epsSphere };
    case 'edge_cd':
    case 'cd':
      return { value: metrics.edges.CD.length, tolerance: tol.epsSphere };

    // Faces (e.g., face_ABC or ABC)
    case 'face_abc':
    case 'abc':
      return { value: metrics.faces.ABC.area, tolerance: tol.epsFaceArea };
    case 'face_abd':
    case 'abd':
      return { value: metrics.faces.ABD.area, tolerance: tol.epsFaceArea };
    case 'face_acd':
    case 'acd':
      return { value: metrics.faces.ACD.area, tolerance: tol.epsFaceArea };
    case 'face_bcd':
    case 'bcd':
      return { value: metrics.faces.BCD.area, tolerance: tol.epsFaceArea };

    // Vertices (e.g., vertex_A or A)
    case 'vertex_a':
    case 'a':
      return { value: state.vertices.A, tolerance: tol.epsSphere };
    case 'vertex_b':
    case 'b':
      return { value: state.vertices.B, tolerance: tol.epsSphere };
    case 'vertex_c':
    case 'c':
      return { value: state.vertices.C, tolerance: tol.epsSphere };
    case 'vertex_d':
    case 'd':
      return { value: state.vertices.D, tolerance: tol.epsSphere };

    default:
      return null;
  }
}

/**
 * Creates a default canonical state of a regular tetrahedron on a unit sphere.
 */
export function getDefaultCanonicalState(radius = 1.0): CanonicalGeometryState {
  const R = radius;
  const sphere = createSphere3D(createPoint3D(0, 0, 0), R);
  const vertices = {
    A: createPoint3D(0, 0, R),
    B: createPoint3D((2 * Math.sqrt(2) / 3) * R, 0, (-1 / 3) * R),
    C: createPoint3D((-Math.sqrt(2) / 3) * R, (-Math.sqrt(6) / 3) * R, (-1 / 3) * R),
    D: createPoint3D((-Math.sqrt(2) / 3) * R, (Math.sqrt(6) / 3) * R, (-1 / 3) * R),
  };
  return createCanonicalGeometryState(sphere, vertices);
}

/**
 * Executes a machine-readable agent request against a canonical geometry state.
 * 
 * Supports either a typed AgentRequest object or a raw JSON string.
 * If currentState is omitted, defaults to the canonical regular tetrahedron state.
 * If the request provides its own `given` state, a new validated state is derived
 * on-the-fly without mutating the fallback state.
 */
export function handleAgentRequest(
  rawRequest: AgentRequest | string,
  currentState?: CanonicalGeometryState
): AgentResponse {
  const activeState = currentState ?? getDefaultCanonicalState();
  let request: AgentRequest;

  if (typeof rawRequest === 'string') {
    try {
      request = JSON.parse(rawRequest);
    } catch (parseErr: any) {
      return {
        operation: 'GET_STATE' as any,
        status: 'MISSING_INPUT',
        evidence: `JSON parse error in agent request payload: ${parseErr.message}`,
      };
    }
  } else {
    request = rawRequest;
  }

  if (!request || !request.operation) {
    return {
      operation: 'GET_STATE' as any,
      status: 'MISSING_INPUT',
      evidence: 'Request missing valid "operation" field (expected GET_STATE, SOLVE, or VERIFY_RESULT).',
    };
  }

  // 1. OPERATION: GET_STATE
  if (request.operation === 'GET_STATE') {
    const validation = validateGeometryState(activeState.sphere, activeState.vertices);
    if (!validation.isValid) {
      return {
        operation: 'GET_STATE',
        status: 'PRECONDITION_FAILED',
        evidence: `Current state is invalid: ${validation.message} (${validation.validationCode}).`,
      };
    }

    const snapshot = extractAgentStateSnapshot(activeState);
    return {
      operation: 'GET_STATE',
      status: 'VALID',
      state: snapshot,
      evidence: `State successfully retrieved. Tetrahedron has 4 vertices on sphere S²(O, R=${activeState.sphere.radius}). Orientation: ${snapshot.orientation}, isRegular: ${snapshot.isRegular}.`,
    };
  }

  // 2. OPERATION: SOLVE
  if (request.operation === 'SOLVE') {
    const solveReq = request as AgentSolveRequest;
    if (!solveReq.target) {
      return {
        operation: 'SOLVE',
        status: 'MISSING_INPUT',
        evidence: 'SOLVE operation requires a "target" field (e.g., "volume", "surface_area", "edge_AB").',
      };
    }

    const validation = validateGeometryState(activeState.sphere, activeState.vertices);
    if (!validation.isValid) {
      return {
        operation: 'SOLVE',
        status: 'PRECONDITION_FAILED',
        target: solveReq.target,
        evidence: `Cannot solve target "${solveReq.target}" because geometry is invalid: ${validation.message} (${validation.validationCode}).`,
      };
    }

    const metrics = computeDerivedMetrics(activeState);
    const resolved = resolveGeometricTarget(solveReq.target, metrics, activeState);

    if (!resolved) {
      return {
        operation: 'SOLVE',
        status: 'UNKNOWN',
        target: solveReq.target,
        evidence: `Unsupported or unknown target: "${solveReq.target}". Supported targets: "volume", "signed_volume", "surface_area", "is_regular", "orientation", "sphere_radius", "centroid", "edge_XX", "face_XXX", "vertex_X".`,
      };
    }

    return {
      operation: 'SOLVE',
      status: 'VALID',
      target: solveReq.target,
      result: resolved.value,
      toleranceUsed: resolved.tolerance,
      evidence: `Deterministic calculation for "${solveReq.target}" succeeded. Value: ${typeof resolved.value === 'object' ? JSON.stringify(resolved.value) : resolved.value}.`,
    };
  }

  // 3. OPERATION: VERIFY_RESULT
  if (request.operation === 'VERIFY_RESULT') {
    const verifyReq = request as AgentVerifyRequest;
    if (!verifyReq.claim || !verifyReq.claim.target) {
      return {
        operation: 'VERIFY_RESULT',
        status: 'MISSING_INPUT',
        evidence: 'VERIFY_RESULT operation requires a "claim" object with "target" and "value".',
      };
    }

    // Determine target geometry state (use given context or fallback to active state)
    let evalState = activeState;
    if (verifyReq.given) {
      const radius = verifyReq.given.radius ?? verifyReq.given.sphere?.radius ?? activeState.sphere.radius;
      const center = verifyReq.given.sphere?.center ?? activeState.sphere.center;
      const sphere = createSphere3D(center, radius);
      const vertices = verifyReq.given.vertices ?? activeState.vertices;

      const validation = validateGeometryState(sphere, vertices);
      if (!validation.isValid) {
        return {
          operation: 'VERIFY_RESULT',
          status: 'PRECONDITION_FAILED',
          target: verifyReq.claim.target,
          claimed: verifyReq.claim.value,
          evidence: `Provided "given" geometry is mathematically invalid: ${validation.message} (${validation.validationCode}). Stand cannot verify claims on invalid geometry.`,
        };
      }
      evalState = createCanonicalGeometryState(sphere, vertices);
    } else {
      const validation = validateGeometryState(evalState.sphere, evalState.vertices);
      if (!validation.isValid) {
        return {
          operation: 'VERIFY_RESULT',
          status: 'PRECONDITION_FAILED',
          target: verifyReq.claim.target,
          claimed: verifyReq.claim.value,
          evidence: `Current geometry is mathematically invalid: ${validation.message} (${validation.validationCode}).`,
        };
      }
    }

    // Stand independently calculates expected ground truth
    const metrics = computeDerivedMetrics(evalState);
    const resolved = resolveGeometricTarget(verifyReq.claim.target, metrics, evalState);

    if (!resolved) {
      return {
        operation: 'VERIFY_RESULT',
        status: 'UNKNOWN',
        target: verifyReq.claim.target,
        claimed: verifyReq.claim.value,
        evidence: `Cannot verify claim for unrecognized target "${verifyReq.claim.target}".`,
      };
    }

    const expected = resolved.value;
    const claimed = verifyReq.claim.value;
    const tolerance = resolved.tolerance;

    // Numerical comparison
    if (typeof expected === 'number') {
      const claimedNum = Number(claimed);
      if (!Number.isFinite(claimedNum)) {
        return {
          operation: 'VERIFY_RESULT',
          status: 'INVALID',
          target: verifyReq.claim.target,
          expected,
          claimed,
          evidence: `Claimed value "${claimed}" is not a finite number.`,
        };
      }

      const diff = Math.abs(claimedNum - expected);
      const isValid = diff <= tolerance;

      return {
        operation: 'VERIFY_RESULT',
        status: isValid ? 'VALID' : 'INVALID',
        target: verifyReq.claim.target,
        expected,
        claimed: claimedNum,
        difference: diff,
        toleranceUsed: tolerance,
        evidence: isValid
          ? `Claim verified: claimed ${claimedNum.toFixed(6)} matches expected ${expected.toFixed(6)} within tolerance ${tolerance.toExponential(2)} (diff = ${diff.toExponential(3)}).`
          : `Claim rejected: claimed ${claimedNum.toFixed(6)} does not match deterministic expected ${expected.toFixed(6)}. Discrepancy ${diff.toFixed(6)} exceeds tolerance ${tolerance.toExponential(2)}.`,
      };
    }

    // Boolean comparison (e.g., is_regular)
    if (typeof expected === 'boolean') {
      const claimedBool = Boolean(claimed);
      const isValid = claimedBool === expected;

      return {
        operation: 'VERIFY_RESULT',
        status: isValid ? 'VALID' : 'INVALID',
        target: verifyReq.claim.target,
        expected,
        claimed: claimedBool,
        toleranceUsed: 0,
        evidence: isValid
          ? `Predicate claim verified: claimed "${claimedBool}" matches deterministic truth "${expected}".`
          : `Predicate claim rejected: claimed "${claimedBool}" contradicts deterministic truth "${expected}".`,
      };
    }

    // String / Orientation comparison
    if (typeof expected === 'string') {
      const claimedStr = String(claimed).trim().toUpperCase();
      const expectedStr = expected.trim().toUpperCase();
      const isValid = claimedStr === expectedStr;

      return {
        operation: 'VERIFY_RESULT',
        status: isValid ? 'VALID' : 'INVALID',
        target: verifyReq.claim.target,
        expected,
        claimed,
        toleranceUsed: 0,
        evidence: isValid
          ? `Categorical claim verified: claimed "${claimedStr}" matches expected "${expectedStr}".`
          : `Categorical claim rejected: claimed "${claimedStr}" does not match expected "${expectedStr}".`,
      };
    }

    // 3D Point comparison (e.g., centroid, vertex)
    if (typeof expected === 'object' && expected !== null && 'x' in expected && 'y' in expected && 'z' in expected) {
      const ptExpected = expected as Point3D;
      if (!claimed || typeof claimed !== 'object' || !('x' in claimed && 'y' in claimed && 'z' in claimed)) {
        return {
          operation: 'VERIFY_RESULT',
          status: 'INVALID',
          target: verifyReq.claim.target,
          expected,
          claimed,
          evidence: `Claimed value is not a valid 3D point {x, y, z}.`,
        };
      }

      const ptClaimed = claimed as Point3D;
      const dist = distance3D(ptClaimed, ptExpected);
      const isValid = dist <= tolerance;

      return {
        operation: 'VERIFY_RESULT',
        status: isValid ? 'VALID' : 'INVALID',
        target: verifyReq.claim.target,
        expected,
        claimed: ptClaimed,
        difference: dist,
        toleranceUsed: tolerance,
        evidence: isValid
          ? `Point claim verified: distance between claimed and expected is ${dist.toExponential(3)} <= tolerance ${tolerance.toExponential(2)}.`
          : `Point claim rejected: distance ${dist.toFixed(6)} exceeds tolerance ${tolerance.toExponential(2)}.`,
      };
    }

    return {
      operation: 'VERIFY_RESULT',
      status: 'UNKNOWN',
      target: verifyReq.claim.target,
      expected,
      claimed,
      evidence: `Unsupported data type comparison for target "${verifyReq.claim.target}".`,
    };
  }

  return {
    operation: (request as any).operation,
    status: 'UNKNOWN',
    evidence: `Unsupported operation: ${(request as any).operation}`,
  };
}

/**
 * Public canonical entry point alias for external agents and clients.
 * Usage: agentRequest(req, state) -> response
 */
export const agentRequest = handleAgentRequest;
