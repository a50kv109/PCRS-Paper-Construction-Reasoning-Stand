/**
 * UNTRUSTED AGENT SIMULATION PROTOCOL
 * 
 * Demonstrates a machine-readable simulation of an external untrusted agent
 * interacting with the Dynamic 3D Geometry Reasoning Stand.
 * 
 * Strict Constraints:
 * 1. The simulator communicates ONLY via the public agentRequest(req, state) interface.
 * 2. It has NO access to private geometry formulas or internal derivations.
 * 3. The stand independently computes and validates all geometric truth.
 */

import { CanonicalGeometryState, Point3D, Sphere3D } from './types';
import { createPoint3D, createSphere3D, createCanonicalGeometryState } from './geometryState';
import { agentRequest, AgentRequest, AgentResponse } from './agentInterface';

export interface SimulationStepLog {
  step: number;
  name: string;
  request: AgentRequest;
  response: AgentResponse;
  expectedStatus: string;
  pass: boolean;
  notes: string;
}

export interface SimulationReport {
  timestamp: string;
  totalSteps: number;
  passedSteps: number;
  failedSteps: number;
  allPassed: boolean;
  correctionLoopPassed: boolean;
  logs: SimulationStepLog[];
  summary: string;
}

/**
 * Runs a deterministic simulation of an untrusted external agent communicating
 * exclusively through the public machine-readable Agent Interface.
 */
export function runUntrustedAgentSimulation(
  initialState?: CanonicalGeometryState
): SimulationReport {
  // Default to standard regular tetrahedron on unit sphere if not provided
  const state: CanonicalGeometryState = initialState ?? (() => {
    const R = 1.0;
    const sphere = createSphere3D(createPoint3D(0, 0, 0), R);
    const vertices = {
      A: createPoint3D(0, 0, R),
      B: createPoint3D((2 * Math.sqrt(2) / 3) * R, 0, (-1 / 3) * R),
      C: createPoint3D((-Math.sqrt(2) / 3) * R, (-Math.sqrt(6) / 3) * R, (-1 / 3) * R),
      D: createPoint3D((-Math.sqrt(2) / 3) * R, (Math.sqrt(6) / 3) * R, (-1 / 3) * R),
    };
    return createCanonicalGeometryState(sphere, vertices);
  })();

  const logs: SimulationStepLog[] = [];
  let stepIndex = 1;

  function executeStep(
    name: string,
    request: AgentRequest,
    expectedStatus: string,
    customValidator?: (res: AgentResponse) => boolean,
    notes: string = ''
  ): AgentResponse {
    const res = agentRequest(request, state);
    const pass = (res.status === expectedStatus) && (customValidator ? customValidator(res) : true);
    logs.push({
      step: stepIndex++,
      name,
      request,
      response: res,
      expectedStatus,
      pass,
      notes,
    });
    return res;
  }

  // ============================================================
  // SCENARIO EXECUTION
  // ============================================================

  // Step 1: Agent requests GET_STATE
  const stateRes = executeStep(
    'GET_STATE',
    { operation: 'GET_STATE' },
    'VALID',
    (res) => res.state !== undefined && res.state.sphere.radius === 1.0,
    'Agent receives current geometry snapshot'
  );

  // Step 2: Agent requests SOLVE for volume
  const solveVolRes = executeStep(
    'SOLVE volume',
    { operation: 'SOLVE', target: 'volume' },
    'VALID',
    (res) => typeof res.result === 'number' && Number(res.result) > 0.5,
    'Stand computes ground truth volume deterministically'
  );

  const exactVolume = typeof solveVolRes.result === 'number' ? solveVolRes.result : 0.5132002392796673;

  // Step 3: Agent verifies correct volume claim
  executeStep(
    'VERIFY_RESULT (correct volume)',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'volume', value: exactVolume },
    },
    'VALID',
    (res) => res.difference !== undefined && res.difference < 1e-10,
    'Stand confirms agent claim within centralized tolerance'
  );

  // Step 4: Agent deliberately submits erroneous volume claim
  executeStep(
    'VERIFY_RESULT (erroneous volume -> negative test)',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'volume', value: 0.500000 },
    },
    'INVALID',
    (res) => res.difference !== undefined && res.difference > 0.01,
    'Stand detects discrepancy exceeding tolerance and rejects claim'
  );

  // Step 5: Agent requests unsupported target
  executeStep(
    'SOLVE (unsupported target)',
    { operation: 'SOLVE', target: 'unsupported_metric_foo' },
    'UNKNOWN',
    undefined,
    'Stand responds with UNKNOWN without hallucinating'
  );

  // Step 6: Agent submits claim on invalid geometry (R = -1)
  const invalidSphere = createSphere3D(createPoint3D(0, 0, 0), -1.0);
  const invalidVertices = {
    A: createPoint3D(0, 0, 1),
    B: createPoint3D(1, 0, 0),
    C: createPoint3D(0, 1, 0),
    D: createPoint3D(0, 0, -1),
  };
  const invalidState = createCanonicalGeometryState(invalidSphere, invalidVertices);
  const invalidRes = agentRequest(
    { operation: 'VERIFY_RESULT', claim: { target: 'volume', value: 0.5 } },
    invalidState
  );
  logs.push({
    step: stepIndex++,
    name: 'VERIFY_RESULT on invalid geometry (R < 0)',
    request: { operation: 'VERIFY_RESULT', claim: { target: 'volume', value: 0.5 } },
    response: invalidRes,
    expectedStatus: 'PRECONDITION_FAILED',
    pass: invalidRes.status === 'PRECONDITION_FAILED',
    notes: 'Stand rejects verification on mathematically invalid pre-state',
  });

  // Step 7: Malicious override attempt (agent asserts 10.0)
  executeStep(
    'Malicious false assertion override attempt',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'volume', value: 10.0 },
    },
    'INVALID',
    (res) => Math.abs(Number(res.expected) - exactVolume) < 1e-6,
    'Stand derives expected value independently and rejects false override'
  );

  // Step 8: Multi-Target Testing (edge_AB, surface_area, orientation)
  // 8a: edge_AB correct and incorrect
  const solveEdgeRes = executeStep(
    'SOLVE edge_AB',
    { operation: 'SOLVE', target: 'edge_AB' },
    'VALID',
    (res) => typeof res.result === 'number' && Number(res.result) > 1.6,
    'Stand solves edge AB chord length'
  );
  const exactEdgeAB = typeof solveEdgeRes.result === 'number' ? solveEdgeRes.result : 1.632993;

  executeStep(
    'VERIFY_RESULT edge_AB (correct)',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'edge_AB', value: exactEdgeAB },
    },
    'VALID',
    undefined,
    'Stand verifies edge_AB length'
  );

  executeStep(
    'VERIFY_RESULT edge_AB (incorrect)',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'edge_AB', value: 2.5 },
    },
    'INVALID',
    undefined,
    'Stand rejects incorrect edge_AB length'
  );

  // 8b: orientation
  executeStep(
    'VERIFY_RESULT orientation POSITIVE (correct)',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'orientation', value: 'POSITIVE' },
    },
    'VALID',
    undefined,
    'Stand verifies positive right-handed orientation'
  );

  executeStep(
    'VERIFY_RESULT orientation NEGATIVE (incorrect)',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'orientation', value: 'NEGATIVE' },
    },
    'INVALID',
    undefined,
    'Stand rejects erroneous orientation assertion'
  );

  // ============================================================
  // STEP 9: AGENT CORRECTION LOOP WORKFLOW
  // 1. Agent hypothesizes wrong value (0.48)
  // 2. Stand verifies -> INVALID with discrepancy evidence
  // 3. Agent parses evidence and updates hypothesis
  // 4. Agent re-submits -> VALID
  // ============================================================
  const loopInitialWrongClaim = 0.480000;
  const loopStep1 = executeStep(
    'CORRECTION LOOP: Agent initial proposal (wrong)',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'volume', value: loopInitialWrongClaim },
    },
    'INVALID',
    (res) => res.status === 'INVALID' && res.expected !== undefined,
    'Correction Loop Step 1: Agent receives INVALID verdict with discrepancy'
  );

  // Agent receives evidence and extracts corrected expected value from stand feedback
  const correctedValue = typeof loopStep1.expected === 'number' ? loopStep1.expected : exactVolume;

  const loopStep2 = executeStep(
    'CORRECTION LOOP: Agent corrected proposal',
    {
      operation: 'VERIFY_RESULT',
      claim: { target: 'volume', value: correctedValue },
    },
    'VALID',
    (res) => res.status === 'VALID',
    'Correction Loop Step 2: Agent resubmits corrected claim and receives VALID'
  );

  const correctionLoopPassed = loopStep1.status === 'INVALID' && loopStep2.status === 'VALID';

  const passedSteps = logs.filter((l) => l.pass).length;
  const totalSteps = logs.length;
  const allPassed = passedSteps === totalSteps && correctionLoopPassed;

  return {
    timestamp: new Date().toISOString(),
    totalSteps,
    passedSteps,
    failedSteps: totalSteps - passedSteps,
    allPassed,
    correctionLoopPassed,
    logs,
    summary: `Untrusted Agent Simulation: ${passedSteps}/${totalSteps} steps passed. Correction loop: ${correctionLoopPassed ? 'PASS' : 'FAIL'}.`,
  };
}
