/**
 * AGENT QUICKSTART EXAMPLE
 * 
 * Minimal demonstration showing how an external AI Agent or script
 * interacts with the 3D Geometry Reasoning Stand via machine-readable contracts.
 * 
 * Flow:
 * 1. Obtain current state (GET_STATE)
 * 2. Request deterministic calculation (SOLVE target: "volume")
 * 3. Submit correct assertion -> Stand returns VALID
 * 4. Submit incorrect assertion -> Stand returns INVALID (Negative verification)
 */

import {
  createPoint3D,
  createSphere3D,
  createCanonicalGeometryState,
  handleAgentRequest,
  AgentRequest,
} from '../src/core';

// 1. Initialize or connect to existing Geometry Stand state
const sphere = createSphere3D(createPoint3D(0, 0, 0), 1.0);
const vertices = {
  A: createPoint3D(0, 0, 1.0),
  B: createPoint3D((2 * Math.sqrt(2) / 3) * 1.0, 0, (-1 / 3) * 1.0),
  C: createPoint3D((-Math.sqrt(2) / 3) * 1.0, (-Math.sqrt(6) / 3) * 1.0, (-1 / 3) * 1.0),
  D: createPoint3D((-Math.sqrt(2) / 3) * 1.0, (Math.sqrt(6) / 3) * 1.0, (-1 / 3) * 1.0),
};
const standState = createCanonicalGeometryState(sphere, vertices);

console.log('=== 1. AGENT: REQUESTING STATE ===');
const stateReq: AgentRequest = { operation: 'GET_STATE' };
const stateRes = handleAgentRequest(stateReq, standState);
console.log('Stand Response:', JSON.stringify(stateRes, null, 2));

console.log('\n=== 2. AGENT: REQUESTING DETERMINISTIC CALCULATION (SOLVE) ===');
const solveReq: AgentRequest = { operation: 'SOLVE', target: 'volume' };
const solveRes = handleAgentRequest(solveReq, standState);
console.log('Stand Response:', JSON.stringify(solveRes, null, 2));

const computedVolume = Number(solveRes.result);

console.log('\n=== 3. AGENT: SUBMITTING CORRECT ASSERTION (VERIFY_RESULT) ===');
const validClaimReq: AgentRequest = {
  operation: 'VERIFY_RESULT',
  claim: {
    target: 'volume',
    value: computedVolume,
  },
};
const validClaimRes = handleAgentRequest(validClaimReq, standState);
console.log('Stand Response:', JSON.stringify(validClaimRes, null, 2));

console.log('\n=== 4. AGENT: SUBMITTING INCORRECT ASSERTION (VERIFY_RESULT) ===');
const invalidClaimReq: AgentRequest = {
  operation: 'VERIFY_RESULT',
  claim: {
    target: 'volume',
    value: 0.500000, // Wrong value!
  },
};
const invalidClaimRes = handleAgentRequest(invalidClaimReq, standState);
console.log('Stand Response (Negative Check):', JSON.stringify(invalidClaimRes, null, 2));

console.log('\n=== 5. AGENT: CORRECTION LOOP WORKFLOW ===');
console.log('Agent received rejection evidence and updates claim to true expected value...');
const correctedClaimReq: AgentRequest = {
  operation: 'VERIFY_RESULT',
  claim: {
    target: 'volume',
    value: invalidClaimRes.expected,
  },
};
const correctedClaimRes = handleAgentRequest(correctedClaimReq, standState);
console.log('Stand Response (Correction Verified):', JSON.stringify(correctedClaimRes, null, 2));

console.log('\n=== 6. AGENT: VERIFYING SECONDARY CLAIM (orientation) ===');
const orientReq: AgentRequest = {
  operation: 'VERIFY_RESULT',
  claim: {
    target: 'orientation',
    value: 'POSITIVE',
  },
};
const orientRes = handleAgentRequest(orientReq, standState);
console.log('Stand Response (Orientation):', JSON.stringify(orientRes, null, 2));
