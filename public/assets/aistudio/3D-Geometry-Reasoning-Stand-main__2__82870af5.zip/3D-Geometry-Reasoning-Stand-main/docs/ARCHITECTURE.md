# System Architecture

## 1. System Overview

The **Dynamic 3D Geometry Reasoning Stand** is a deterministic mathematical instrument designed for observing, verifying, and reasoning about geometric transformations in three-dimensional space.

The system is constructed upon a single authoritative rule:
> **The Agent May Be Wrong. The Stand Must Not.**

External artificial intelligence agents, automated theorem reasoners, or student users can interact with the geometry stand by asserting hypotheses or executing transformations. The stand observes these actions, projects causal neighborhoods, and deterministically computes mathematical truth.

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                           UNTRUSTED CLIENTS                             │
│      AI Agents (LLMs)   │   Human Learners   │   External Reasoners     │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ Actions / Claims
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      VERIFICATION BOUNDARY (Pkg 05)                     │
│        VERIFY_RESULT     │     VERIFY_STEP     │    CONSISTENCY_CHECK   │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ Validated Transitions
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                ONE CANONICAL GEOMETRY STATE (Pkg 01, 02)                │
│    Fixed Sphere S²(O, R)   │   Persistent Vertices A, B, C, D ∈ ℝ³      │
│    Combinatorial Topology: 4 Vertices, 6 Euclidean Edges, 4 Flat Faces  │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ Feeds
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                DETERMINISTIC COMPUTATIONAL ENGINE (Pkg 03)              │
│    Full Recomputation Baseline Oracle │ Scale-Aware Tolerances (Pkg 06) │
│    Chords L_ij  │ Face Areas S_F  │ Normals n_F  │ Signed Volume V_s    │
│    Regularity Predicate  │  Metadata-Free FNV-1a Geometry Signature     │
└──────────────────┬─────────────────┬─────────────────┬──────────────────┘
                   │                 │                 │
                   ▼                 ▼                 ▼
          ┌─────────────────┐ ┌──────────────┐ ┌───────────────┐
          │ REPRESENTATION  │ │ VISUALIZATION│ │   TEMPORAL    │
          │     LAYER       │ │  WORKBENCH   │ │  OBSERVATION  │
          │ (Lat/Lon (φ, λ))│ │  (React/3D)  │ │ (Snapshots)   │
          └─────────────────┘ └──────────────┘ └───────────────┘
```

---

## 2. The Multi-Layer State Model

To eliminate circular dependencies and state leakage, the system strictly separates state into three distinct layers:

| Layer | State Components | Ownership & Mutability |
| :--- | :--- | :--- |
| **Geometry State** | Canonical Cartesian coordinates: Center $O$, radius $R$, vertices $A, B, C, D \in \mathbb{R}^3$. | Immutable snapshot (`CanonicalGeometryState`). Deeply frozen. Mutated exclusively via explicit geometric transitions. |
| **Representation State** | Spherical coordinates $(\phi, \lambda)$ on $S^2$, coordinate guides (parallels, meridians), fixed reference axes. | Derived purely on-demand as a mathematical bijection. Never alters canonical Cartesian coordinates. |
| **Visualization State** | Camera orbit (azimuth $\theta$, elevation $\psi$, distance $d$), viewport dimensions, visual scale ($100\%, 75\%, 50\%$), selection highlights. | Local client state. Zero mathematical authority; modifying visual properties produces zero changes in geometry or signatures. |

---

## 3. Canonical Geometry & Topology

The geometry core operates exclusively in three-dimensional Euclidean space $\mathbb{R}^3$:

- **The World Sphere $S^2(O, R)$:**
  Defined by fixed center $O(0, 0, 0)$ and positive radius $R > 0$. Vertices are constrained to lie on this surface:
  $$\|V_i - O\|_2 = R \quad \text{for } V_i \in \{A, B, C, D\}$$
- **Persistent Combinatorial Topology (4V / 6E / 4F):**
  - Vertices retain labeled identities $A, B, C, D$ indefinitely. They are never sorted by distance or re-indexed.
  - Exactly 6 straight Euclidean edges: $AB, AC, AD, BC, BD, CD$. Edges are chords traversing the interior of the sphere.
  - Exactly 4 planar triangular faces: $ABC, ABD, ACD, BCD$. Faces are flat planes in $\mathbb{R}^3$, not spherical patches.

---

## 4. Representation Layer (Dual Coordinates)

While Cartesian coordinates form the canonical source of truth, spherical coordinates provide intuitive human and robotic control:
- **Latitude $\phi \in [-\pi/2, \pi/2]$**: Angle relative to the equatorial plane ($XY$).
- **Longitude $\lambda \in [0, 2\pi)$**: Counter-clockwise angle from $+X$ (prime meridian).

### Mathematical Conversion
$$\begin{pmatrix} x \\ y \\ z \end{pmatrix} = \begin{pmatrix} O_x + R \cos\phi \cos\lambda \\ O_y + R \cos\phi \sin\lambda \\ O_z + R \sin\phi \end{pmatrix}$$
$$\phi = \arcsin\left(\operatorname{clamp}\left(\frac{z - O_z}{R}, -1, 1\right)\right), \quad \lambda = \operatorname{atan2}(y - O_y, x - O_x) \pmod{2\pi}$$

- **Pole Singularity Invariant:** If $|\phi| = \pi/2$ (within $\text{EPS\_ANGLE}$), $\lambda$ is canonicalized to $0$.
- **Anti-Silent-Projection Guard:** If an external input specifies Cartesian coordinates where $|\|P - O\| - R| > \epsilon_{\text{sphere}}$, the engine explicitly rejects the point with `OUTSIDE_SPHERE`. No silent radial snapping or projection is permitted.

---

## 5. Dependency Graph & Semantic Impact Model

When a vertex (e.g., $D$) is moved:
- **Structurally Incident Branch:** Edges $\{AD, BD, CD\}$ and faces $\{ABD, ACD, BCD\}$ are incident and must be evaluated.
- **Invariant Disjoint Branch:** Edge $\{BC\}$ and opposite face $\{ABC\}$ are structurally disjoint from $D$. Their lengths, areas, and plane orientations are mathematically guaranteed to remain invariant.

```text
Move Vertex D
  │
  ├─► Incident Edges:  AD, BD, CD (Lengths updated)
  ├─► Incident Faces:  ABD, ACD, BCD (Areas & Normals updated)
  │
  ├─► Global State:    Signed Volume V_s, Total Surface Area, Centroid G
  │
  └─► Invariant:       Edge BC, Face ABC (Unaltered, Verified Invariant)
```

The stand maintains full label permutation symmetry across all four vertices $A, B, C, D$.

---

## 6. Deterministic Engine & Recomputation Oracle

The engine executes a feed-forward deterministic derivation:
$$\text{Input State } \to \text{Tolerance Resolution } \to \text{Metrics } \to \text{Solid Orientation } \to \text{Predicates } \to \text{Signature}$$

### Full Recomputation Baseline
Rather than relying on mutable incremental cache invalidation, the engine evaluates the full derivation graph from the ground up for every state transition. This full deterministic recomputation serves as the **authoritative baseline oracle** against which any future incremental optimizations must be validated.

---

## 7. Metadata-Free Geometry Signature

To uniquely identify geometric states, the stand computes an FNV-1a 32-bit hash strictly from normalized geometric properties:
$$\text{Signature} = \operatorname{FNV1a}\left(R \parallel A_{x,y,z} \parallel B_{x,y,z} \parallel C_{x,y,z} \parallel D_{x,y,z} \parallel L_{1..6} \parallel S_{1..4} \parallel V_s \parallel \text{Orientation} \parallel \text{Regularity}\right)$$
All numerical values are formatted to 10 fixed decimal places. Timestamps, client IDs, viewport sizes, and camera orientations are strictly excluded, ensuring bitwise identical signatures across disparate runtime environments.

---

## 8. Verification & Research Boundaries

```text
┌──────────────────────────────────────────────────────────────────────────┐
│                      VERIFICATION BOUNDARY (CORE)                        │
│                                                                          │
│  • Strictly evaluates external claims against deterministic recomputation │
│  • Orthogonal status taxonomies: Verification, Input, Solid, Consistency │
│  • Provenance tracking: DETERMINISTIC_DERIVATION vs AGENT_ASSERTION      │
│  • Anti-circular guard: Assertions cannot verify assertions             │
└──────────────────────────────────────────────────────────────────────────┘
                                     │
                        STRICT BOUNDARY / GATEWAY
                                     │
┌──────────────────────────────────────────────────────────────────────────┐
│                      RESEARCH BOUNDARY (LABORATORY)                      │
│                                                                          │
│  • Isolated exploratory sandbox for unverified mathematical hypotheses   │
│  • 81 Face-Center classification profile realizability                   │
│  • Automatic symbolic theorem discovery and proof-tree generators        │
│  • Unvalidated conjectures are quarantined from the Core Engine          │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 9. Centralized Scale-Aware Tolerance Architecture

Per Package 06, all numerical tolerances are dimensionally derived from characteristic length $L_{\text{scale}} = R$:

$$\epsilon_Q = c_Q \cdot R^{\operatorname{dim}(Q)}$$

- Lengths ($\mathsf{L}^1$): $\epsilon = 10^{-6} R$
- Areas ($\mathsf{L}^2$): $\epsilon = 10^{-6} R^2$
- Volumes ($\mathsf{L}^3$): $\epsilon = 10^{-7} R^3$
- Regularity ($\mathsf{L}^0$): Dimensionless ratio $(L_{\max} - L_{\min})/R \le 10^{-4}$
- Angles ($\mathsf{L}^0$): $\epsilon = 10^{-6} \text{ rad}$

This guarantees that the system behaves identically across any scale from micro-geometry ($R = 10^{-6}$) to astronomical scales ($R = 10^6$).
