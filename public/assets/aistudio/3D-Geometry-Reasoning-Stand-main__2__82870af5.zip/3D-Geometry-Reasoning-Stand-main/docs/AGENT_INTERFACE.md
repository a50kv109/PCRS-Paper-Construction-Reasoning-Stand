# Agent Interface Contract

**Stand:** Dynamic 3D Geometry Reasoning Stand  
**Role:** Deterministic Verifier for Inscribed Tetrahedra on $S^2(O, R)$  
**Trust Model:** The external agent is **untrusted**. The Stand independently computes mathematical ground truth using the centralized scale-aware tolerance policy.

---

## 1. Trust Boundary & Principles

```text
┌────────────────────────┐
│    External Agent      │  (Untrusted: explores, hypothesizes, claims)
└───────────┬────────────┘
            │  Domain-level Request (JSON / Object)
            ▼
┌────────────────────────┐
│  Stand Agent Interface │  (Evaluates request using Canonical Geometry Core)
└───────────┬────────────┘
            │  Independent Recalculation & Tolerance Validation
            ▼
┌────────────────────────┐
│  Deterministic Result  │  (VALID / INVALID / UNKNOWN / PRECONDITION_FAILED)
└────────────────────────┘
```

1. **Agent May Be Wrong, Stand Must Not:** Agent claims are checked against deterministic calculations; agent values are never trusted or cached as ground truth.
2. **Domain Concepts Only:** Agents interact with natural geometric terms (`volume`, `surface_area`, `edge_AB`, `face_ABC`, `orientation`, `is_regular`, `centroid`, `sphere_radius`, `vertex_A`).
3. **Scale-Aware Tolerance:** Tolerances scale deterministically with sphere radius $R$ ($\epsilon_V = 10^{-7} R^3$, $\epsilon_A = 10^{-6} R^2$, $\epsilon_L = 10^{-6} R$).

---

## 2. Operations & Schema

### A. `GET_STATE`
Retrieves machine-readable snapshot of the current geometry.

**Request:**
```json
{
  "operation": "GET_STATE"
}
```

**Response:**
```json
{
  "operation": "GET_STATE",
  "status": "VALID",
  "state": {
    "sphere": { "center": { "x": 0, "y": 0, "z": 0 }, "radius": 1 },
    "vertices": {
      "A": { "x": 0, "y": 0, "z": 1 },
      "B": { "x": 0.9428, "y": 0, "z": -0.3333 },
      "C": { "x": -0.4714, "y": -0.8165, "z": -0.3333 },
      "D": { "x": -0.4714, "y": 0.8165, "z": -0.3333 }
    },
    "isValid": true,
    "validationCode": "VALID",
    "orientation": "POSITIVE",
    "isRegular": true,
    "measurements": {
      "volume": 0.513200,
      "surface_area": 4.618802,
      "edge_lengths": { "AB": 1.632993, "AC": 1.632993, "AD": 1.632993, "BC": 1.632993, "BD": 1.632993, "CD": 1.632993 },
      "face_areas": { "ABC": 1.154701, "ABD": 1.154701, "ACD": 1.154701, "BCD": 1.154701 },
      "centroid": { "x": 0, "y": 0, "z": 0 }
    }
  },
  "evidence": "State successfully retrieved..."
}
```

---

### B. `SOLVE`
Asks the deterministic stand to compute a geometric target.

**Request:**
```json
{
  "operation": "SOLVE",
  "target": "volume"
}
```

**Response:**
```json
{
  "operation": "SOLVE",
  "status": "VALID",
  "target": "volume",
  "result": 0.5132002392796673,
  "toleranceUsed": 1e-7,
  "evidence": "Deterministic calculation for \"volume\" succeeded."
}
```

---

### C. `VERIFY_RESULT`
Submits an agent hypothesis or claimed value for independent mathematical verification.

**Request:**
```json
{
  "operation": "VERIFY_RESULT",
  "claim": {
    "target": "volume",
    "value": 0.5132002392796673
  }
}
```

---

## 3. Statuses

| Status | Meaning |
|---|---|
| `VALID` | Claim verified within centralized tolerance / calculation succeeded |
| `INVALID` | Claim refuted by deterministic reference calculation (exceeds tolerance) |
| `UNKNOWN` | Target is not recognized or not supported |
| `PRECONDITION_FAILED` | Underlying geometry is invalid (e.g., $R \le 0$, vertex outside sphere) |
| `MISSING_INPUT` | Required fields missing in request payload |

---

## 4. Concrete Examples

### Correct Example (VALID)
**Request:**
```json
{
  "operation": "VERIFY_RESULT",
  "claim": {
    "target": "volume",
    "value": 0.5132002392796673
  }
}
```
**Stand Response:**
```json
{
  "operation": "VERIFY_RESULT",
  "status": "VALID",
  "target": "volume",
  "expected": 0.5132002392796673,
  "claimed": 0.5132002392796673,
  "difference": 0,
  "toleranceUsed": 1e-7,
  "evidence": "Claim verified: claimed 0.513200 matches expected 0.513200 within tolerance 1.00e-7."
}
```

### Incorrect Example (INVALID — Negative Verification)
**Request:**
```json
{
  "operation": "VERIFY_RESULT",
  "claim": {
    "target": "volume",
    "value": 0.500000
  }
}
```
**Stand Response:**
```json
{
  "operation": "VERIFY_RESULT",
  "status": "INVALID",
  "target": "volume",
  "expected": 0.5132002392796673,
  "claimed": 0.5,
  "difference": 0.013200239279667292,
  "toleranceUsed": 1e-7,
  "evidence": "Claim rejected: claimed 0.500000 does not match deterministic expected 0.513200. Discrepancy 0.013200 exceeds tolerance 1.00e-7."
}
```

---

## 5. Agent Correction Loop Workflow

The stand supports the iterative hypothesis-refinement loop:

```text
  ┌──────────────┐
  │   AI AGENT   │  Proposes initial estimate: volume = 0.500000
  └──────┬───────┘
         │  VERIFY_RESULT
         ▼
  ┌──────────────┐
  │  STAND CORE  │  Calculates ground truth (0.513200)
  └──────┬───────┘  Verdict: INVALID (Discrepancy 0.013200 > tolerance)
         │
         ▼
  ┌──────────────┐
  │   AI AGENT   │  Parses evidence, updates hypothesis to 0.513200
  └──────┬───────┘
         │  VERIFY_RESULT
         ▼
  ┌──────────────┐
  │  STAND CORE  │  Verdict: VALID (diff < tolerance)
  └──────────────┘
```

---

## 6. Secondary Non-Volume Claims

The interface evaluates all continuous and categorical geometric targets without hardcoding:

### Edge Length (`edge_AB`)
```json
{
  "operation": "VERIFY_RESULT",
  "claim": { "target": "edge_AB", "value": 1.632993 }
}
```
$\rightarrow$ Returns `VALID` for $R=1$ regular tetrahedron, or `INVALID` if discrepancy exceeds $\epsilon_L = 10^{-6} R$.

### Orientation (`orientation`)
```json
{
  "operation": "VERIFY_RESULT",
  "claim": { "target": "orientation", "value": "POSITIVE" }
}
```
$\rightarrow$ Returns `VALID` if signed volume $> 0$, or `INVALID` for `"NEGATIVE"`.

---

## 7. Execution Status & Realism Disclosure

- **LOCAL DETERMINISTIC AGENT SIMULATION:** `PASS` (Verified via `npm run test:all` and `src/tests/agent_readiness_smoke.test.ts`)
- **LIVE INDEPENDENT EXTERNAL LLM AGENT:** `NOT EXECUTED`

> **Note on Verification:** The local test suite simulates the protocol and untrusted behavior deterministically. No independent external LLM process is connected or claimed to be connected.
